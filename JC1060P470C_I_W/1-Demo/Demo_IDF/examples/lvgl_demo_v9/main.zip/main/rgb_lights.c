#include <stdio.h>
#include "ui.h"
#include "lvgl.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_check.h"
#include "esp_memory_utils.h"
#include "bsp/esp-bsp.h"
#include "bsp/display.h"
#include "bsp_board_extra.h"
#include "lv_demos.h"
#include "header.h"
#include "screens.h"

typedef struct {
    int            id;
    bool           is_on;
    int            current_intensity;
    rgb_current_t  color;
    char           name[32];

    lv_obj_t *rgbw_button;
    lv_obj_t *rgbw_label;
    lv_obj_t *rgbw_light_indicator;
    lv_obj_t *button_img_on_off_rgbw;
    lv_obj_t *reg_rgb_img;
    lv_obj_t *green_rgbw_img;
    lv_obj_t *blue_rgbw_img;
    lv_obj_t *color_picker_img;
} rgb_device_t;

#define MAX_RGB 20
static rgb_device_t  my_rgbs[MAX_RGB];
static int           rgb_count  = 0;
static rgb_device_t *active_rgb = NULL;

void create_rgb_widget(const char *rgb_name, lv_obj_t *parent_panel);
void create_rgb_widget_big(const char *rgb_name, lv_obj_t *parent_panel);
void rgbw_light_init(void);

// ── arc colour from active channel ──────────────────────────────────────────
static lv_color_t channel_to_color(rgb_device_t *rgb)
{
    if (rgb->color.r > 0 && rgb->color.g == 0 && rgb->color.b == 0)
        return lv_color_hex(0xFF0000);
    if (rgb->color.g > 0 && rgb->color.r == 0 && rgb->color.b == 0)
        return lv_color_hex(0x00FF00);
    if (rgb->color.b > 0 && rgb->color.r == 0 && rgb->color.g == 0)
        return lv_color_hex(0x0000FF);
    return lv_color_hex(0xFFBA00);
}

// ── sync widget UI ───────────────────────────────────────────────────────────
// FIX 1: Arc is either FULL (10) or ZERO (0) — snaps, no partial fill
// FIX 2: arc indicator colour + image checked state both updated together
static void sync_widget_ui(rgb_device_t *rgb)
{
    lv_color_t col = channel_to_color(rgb);

    // Arc: snap to full or zero
    lv_arc_set_value(rgb->rgbw_light_indicator, rgb->is_on ? 10 : 0);

    // Arc indicator colour changes with selected channel
    lv_obj_set_style_arc_color(rgb->rgbw_light_indicator, col,
                               LV_PART_INDICATOR | LV_STATE_DEFAULT);

    // On/off image: checked = ON lamp image, unchecked = OFF lamp image
    if (rgb->is_on)
    {
        lv_obj_add_state(rgb->button_img_on_off_rgbw, LV_STATE_CHECKED);
         lv_obj_set_style_img_recolor(rgb->button_img_on_off_rgbw, col, 0);
        lv_obj_set_style_img_recolor_opa(rgb->button_img_on_off_rgbw, LV_OPA_100, 0);
    }    else
        lv_obj_clear_state(rgb->button_img_on_off_rgbw, LV_STATE_CHECKED);
        lv_obj_invalidate(rgb->button_img_on_off_rgbw);

    printf("rgb [%s] on=%d R=%d G=%d B=%d\n",
           rgb->name, rgb->is_on,
           rgb->color.r, rgb->color.g, rgb->color.b);
}

static void sync_big_screen(rgb_device_t *rgb)
{
    if (!rgb) return;
    lv_label_set_text(objects.rgbw_screen_label, rgb->name);
    lv_slider_set_range(objects.brightness_dim_rgb_slider_panel, 0, 10);
    lv_slider_set_value(objects.brightness_dim_rgb_slider_panel,
                        rgb->current_intensity, LV_ANIM_OFF);
}

// ── widget button callback ───────────────────────────────────────────────────
static void rgb_widget_cb(lv_event_t *e)
{
    lv_obj_t     *target = lv_event_get_target(e);
    rgb_device_t *rgb    = (rgb_device_t *)lv_event_get_user_data(e);

    if (target == rgb->button_img_on_off_rgbw)
    {
        rgb->is_on = !rgb->is_on;
        rgb->current_intensity = rgb->is_on ? 10 : 0;
        if (!rgb->is_on) { rgb->color.r = 0; rgb->color.g = 0; rgb->color.b = 0; }
    }
    else if (target == rgb->reg_rgb_img)
    {
        rgb->color.r = 255; rgb->color.g = 0; rgb->color.b = 0;
        rgb->is_on = true;  rgb->current_intensity = 10;
    }
    else if (target == rgb->green_rgbw_img)
    {
        rgb->color.r = 0; rgb->color.g = 255; rgb->color.b = 0;
        rgb->is_on = true; rgb->current_intensity = 10;
    }
    else if (target == rgb->blue_rgbw_img)
    {
        rgb->color.r = 0; rgb->color.g = 0; rgb->color.b = 255;
        rgb->is_on = true; rgb->current_intensity = 10;
    }
    else if (target == rgb->color_picker_img)
    {
        active_rgb = rgb;
        sync_big_screen(rgb);
        lv_obj_clear_flag(objects.rgb_screen_container, LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_foreground(objects.rgb_screen_container);
        return;
    }

    rgb->is_on = (rgb->current_intensity > 0);
    sync_widget_ui(rgb);
    if (active_rgb == rgb) sync_big_screen(rgb);
}

// ── arc drag: snap full or zero ──────────────────────────────────────────────
static void rgb_arc_cb(lv_event_t *e)
{
    rgb_device_t *rgb = (rgb_device_t *)lv_event_get_user_data(e);
    int val = lv_arc_get_value(rgb->rgbw_light_indicator);

    rgb->is_on = (val > 5);
    rgb->current_intensity = rgb->is_on ? 10 : 0;
    if (!rgb->is_on) { rgb->color.r = 0; rgb->color.g = 0; rgb->color.b = 0; }

    sync_widget_ui(rgb);
    if (active_rgb == rgb) sync_big_screen(rgb);
}

static void rgb_screen_slider_cb(lv_event_t *e)
{
    if (!active_rgb) return;
    int val = lv_slider_get_value(objects.brightness_dim_rgb_slider_panel);
    active_rgb->current_intensity = val;
    active_rgb->is_on = (val > 0);
    if (!active_rgb->is_on) {
        active_rgb->color.r = 0; active_rgb->color.g = 0; active_rgb->color.b = 0;
    }
    sync_widget_ui(active_rgb);
}

static void rgb_callback(lv_event_t *e)
{
    lv_obj_t *target = lv_event_get_target(e);
    if (target == objects.back_button_label_rgb_screen) {
        lv_obj_add_flag(objects.rgb_screen_container, LV_OBJ_FLAG_HIDDEN);
        active_rgb = NULL;
    } else if (target == objects.white_panel_back_button_label) {
        lv_obj_add_flag(objects.white_screen_rgb, LV_OBJ_FLAG_HIDDEN);
    } else if (target == objects.small_white_img) {
        lv_obj_clear_flag(objects.white_screen_rgb, LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_foreground(objects.white_screen_rgb);
    } else if (target == objects.color_img_inside_white_panel) {
        lv_obj_add_flag(objects.white_screen_rgb, LV_OBJ_FLAG_HIDDEN);
    }
}

void reset_rgb_widgets(void)
{
    rgb_count  = 0;
    active_rgb = NULL;
    lv_obj_clean(objects.cct_rgb_light_panel);
    printf("RGB reset OK\n");
}

void rgbw_light_init(void)
{
    lv_slider_set_range(objects.brightness_dim_rgb_slider_panel, 0, 10);
    lv_obj_add_event_cb(objects.back_button_label_rgb_screen,  rgb_callback, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(objects.white_panel_back_button_label, rgb_callback, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(objects.small_white_img,               rgb_callback, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(objects.color_img_inside_white_panel,  rgb_callback, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(objects.brightness_dim_rgb_slider_panel, rgb_screen_slider_cb, LV_EVENT_VALUE_CHANGED, NULL);

#ifdef MANUAL
    create_rgb_widget("RGB Light 1", objects.cct_rgb_light_panel);
    create_rgb_widget("RGB Light 2", objects.cct_rgb_light_panel);
    create_rgb_widget("LED Strip 1", objects.cct_rgb_light_panel);
#endif
}

// ── shared setup after EES builds the tree ───────────────────────────────────
static void _rgb_setup(rgb_device_t *rgb, lv_obj_t *parent_panel, const char *rgb_name)
{
    rgb->id = rgb_count; rgb->is_on = false; rgb->current_intensity = 0;
    rgb->color.r = 0; rgb->color.g = 0; rgb->color.b = 0;
    lv_snprintf(rgb->name, sizeof(rgb->name), "%s", rgb_name);

    uint32_t total   = lv_obj_get_child_cnt(parent_panel);
    rgb->rgbw_button = lv_obj_get_child(parent_panel, total - 1);

    // FIX 3: panel is LV_LAYOUT_FLEX ROW — force fixed size so the button
    // doesn't stretch and swallow the entire panel width
    lv_obj_set_size(rgb->rgbw_button, 230, 305);
    lv_obj_remove_flag(rgb->rgbw_button, LV_OBJ_FLAG_SCROLL_ON_FOCUS);

    rgb->rgbw_label             = lv_obj_get_child(rgb->rgbw_button, 0);
    rgb->rgbw_light_indicator   = lv_obj_get_child(rgb->rgbw_button, 1);
    rgb->button_img_on_off_rgbw = lv_obj_get_child(rgb->rgbw_light_indicator, 0);
    rgb->reg_rgb_img            = lv_obj_get_child(rgb->rgbw_button, 2);
    rgb->green_rgbw_img         = lv_obj_get_child(rgb->rgbw_button, 3);
    rgb->blue_rgbw_img          = lv_obj_get_child(rgb->rgbw_button, 4);
    rgb->color_picker_img       = lv_obj_get_child(rgb->rgbw_button, 5);

    lv_label_set_text(rgb->rgbw_label, rgb->name);
    lv_arc_set_range(rgb->rgbw_light_indicator, 0, 10);
    lv_arc_set_value(rgb->rgbw_light_indicator, 0);

    lv_obj_add_event_cb(rgb->button_img_on_off_rgbw, rgb_widget_cb, LV_EVENT_CLICKED, rgb);
    lv_obj_add_event_cb(rgb->reg_rgb_img,            rgb_widget_cb, LV_EVENT_CLICKED, rgb);
    lv_obj_add_event_cb(rgb->green_rgbw_img,         rgb_widget_cb, LV_EVENT_CLICKED, rgb);
    lv_obj_add_event_cb(rgb->blue_rgbw_img,          rgb_widget_cb, LV_EVENT_CLICKED, rgb);
    lv_obj_add_event_cb(rgb->color_picker_img,       rgb_widget_cb, LV_EVENT_CLICKED, rgb);
    lv_obj_add_event_cb(rgb->rgbw_light_indicator,   rgb_arc_cb,    LV_EVENT_VALUE_CHANGED, rgb);

    rgb_count++;
    printf("RGB widget created: [%s] id=%d\n", rgb->name, rgb->id);
}

void create_rgb_widget(const char *rgb_name, lv_obj_t *parent_panel)
{
    if (rgb_count >= MAX_RGB) { printf("ERROR: MAX_RGB limit reached!\n"); return; }
    create_user_widget_rgbw_button(parent_panel, NULL, 0);
    _rgb_setup(&my_rgbs[rgb_count], parent_panel, rgb_name);
}

void create_rgb_widget_big(const char *rgb_name, lv_obj_t *parent_panel)
{
    if (rgb_count >= MAX_RGB) { printf("ERROR: MAX_RGB limit reached!\n"); return; }
    // TODO: swap to create_user_widget_rgbw_button_big() when you create it in EES
    create_user_widget_rgbw_button(parent_panel, NULL, 0);
    _rgb_setup(&my_rgbs[rgb_count], parent_panel, rgb_name);
}