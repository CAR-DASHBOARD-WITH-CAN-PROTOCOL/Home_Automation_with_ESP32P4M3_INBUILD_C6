#include <stdio.h>
#include "ui.h"
#include "lvgl.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "esp_log.h"
#include "esp_err.h"
#include "esp_check.h"
#include "esp_memory_utils.h"
#include "bsp/esp-bsp.h"
#include "bsp/display.h"
#include "bsp_board_extra.h"
#include "lv_demos.h"
#include "header.h"
#include "screens.h"
// ─── NEW INCLUDES FOR UART ─────────────────────────────────
#include "driver/uart.h"
#include "driver/gpio.h"


// ─── UART CONFIGURATION FOR P4 (INTERNAL ROUTING) ──────────
#define P4_UART_PORT      UART_NUM_1 
#define P4_UART_BAUD      115200
#define P4_UART_TX_PIN    15         // P4 TX routed to C6 RX (Pin 21)
#define P4_UART_RX_PIN    14         // P4 RX routed from C6 TX (Pin 20)
#define P4_UART_BUF_SIZE  1024

static const char *TAG = "P4_MAIN";

void p4_uart_init(void);
// ─── UART INITIALIZATION ───────────────────────────────────

 #ifdef listen
void p4_uart_init(void)
{
    uart_config_t uart_config = {
        .baud_rate  = P4_UART_BAUD,
        .data_bits  = UART_DATA_8_BITS,
        .parity     = UART_PARITY_DISABLE,
        .stop_bits  = UART_STOP_BITS_1,
        .flow_ctrl  = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    
    ESP_ERROR_CHECK(uart_param_config(P4_UART_PORT, &uart_config));
    ESP_ERROR_CHECK(uart_set_pin(P4_UART_PORT, P4_UART_TX_PIN, P4_UART_RX_PIN, 
                                 UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    ESP_ERROR_CHECK(uart_driver_install(P4_UART_PORT, P4_UART_BUF_SIZE, P4_UART_BUF_SIZE, 0, NULL, 0));
    
    ESP_LOGI(TAG, "Internal UART Listener initialized (TX=%d, RX=%d)", P4_UART_TX_PIN, P4_UART_RX_PIN);
}

// ─── UART LISTENER TASK ────────────────────────────────────
static void c6_listener_task(void *arg)
{
    uint8_t rx_buffer[P4_UART_BUF_SIZE];
   
    while (1) {
        // Read data from the UART with a 100ms timeout
        int rx_bytes = uart_read_bytes(P4_UART_PORT, rx_buffer, P4_UART_BUF_SIZE - 1, pdMS_TO_TICKS(100));
        printf("inside uart while\n");
        if (rx_bytes > 0) {
            rx_buffer[rx_bytes] = '\0'; // Null-terminate the string safely
            
            // Log exactly what the C6 sent
            ESP_LOGI(TAG, "Received from C6: %s", rx_buffer);
            
            // ─── PARSE COMMANDS FROM C6 ───
            if (strstr((char *)rx_buffer, "CONNECTION_SUCCESSFUL")) {
                ESP_LOGI(TAG, "C6 reported WiFi is CONNECTED!");
                
                // CRITICAL: Always lock the display before touching LVGL objects from a FreeRTOS task!
                // bsp_display_lock(0);
                
                // // TODO: Update your UI here. For example:
                // // lv_label_set_text(ui_WifiStatusLabel, "Connected");
                // // lv_obj_set_style_img_recolor(ui_WifiIcon, lv_color_hex(0x00FF00), 0);
                
                // bsp_display_unlock();
            }
            else if (strstr((char *)rx_buffer, "WIFI_FAILED") || strstr((char *)rx_buffer, "WIFI_FAIL")) {
                ESP_LOGW(TAG, "C6 reported WiFi FAILED!");
                
                // bsp_display_lock(0);
                // // TODO: Update your UI to show disconnected state
                // bsp_display_unlock();
            }
            else if (strstr((char *)rx_buffer, "C6_BOOTING")) {
                ESP_LOGI(TAG, "C6 is booting up...");
            }
        }
   
        // Yield to prevent task watchdog timeouts
        vTaskDelay(pdMS_TO_TICKS(1000)); 
    }
}
     #endif

